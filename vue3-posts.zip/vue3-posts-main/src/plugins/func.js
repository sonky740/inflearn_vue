function funcPlugins() {
	console.log('funcPlugins');
}
export default funcPlugins;
