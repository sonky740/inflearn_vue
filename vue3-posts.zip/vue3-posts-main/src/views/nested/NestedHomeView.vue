<template>
	<div class="card">
		<div class="card-header">Nested Home</div>
		<div class="card-body">
			<h1 class="card-title">Nested routes home...</h1>
		</div>
	</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
