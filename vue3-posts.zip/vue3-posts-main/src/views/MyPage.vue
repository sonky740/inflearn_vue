<template>
	<div>
		<h2>MyPage</h2>
		<hr />
	</div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
