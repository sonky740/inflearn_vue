function color(el, binding) {
	el.style.color = binding.value;
}

export default color;
